// sw.js — Service Worker do Alerta EPI
// Responsável por: instalar o app como PWA, manter cache offline,
// e exibir notificações agendadas mesmo com o app em segundo plano.

const CACHE_NAME = "alerta-epi-v1";
const ARQUIVOS = ["./index.html", "./manifest.json", "./icon.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ARQUIVOS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((resp) => resp || fetch(event.request))
  );
});

// Recebe um pedido da página para mostrar uma notificação imediatamente
self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type === "SHOW_NOTIFICATION") {
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "./icon.svg",
      badge: "./icon.svg",
      vibrate: [200, 100, 200],
      tag: data.tag || "epi-alerta",
      requireInteraction: true,
      renotify: true
    });
  }
});

// Caso o navegador suporte Periodic Background Sync, usamos para
// reavaliar se há notificação pendente mesmo com o app fechado.
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "checar-plantao") {
    event.waitUntil(checarEAvisar());
  }
});

// Fallback: alguns navegadores Android disparam "sync" comum.
self.addEventListener("sync", (event) => {
  if (event.tag === "checar-plantao") {
    event.waitUntil(checarEAvisar());
  }
});

async function checarEAvisar() {
  // Lê a configuração salva pela página (setor + horário) via IndexedDB-like
  // simplificado usando Cache Storage como armazenamento de config.
  try {
    const cache = await caches.open(CACHE_NAME);
    const resp = await cache.match("./config-virtual");
    if (!resp) return;
    const config = await resp.json();
    if (!config || !config.proximaNotificacao) return;

    const agora = Date.now();
    const alvo = config.proximaNotificacao.timestamp;
    // Janela de 2 minutos para disparo (periodicsync não é exato)
    if (Math.abs(agora - alvo) <= 2 * 60 * 1000) {
      await self.registration.showNotification(config.proximaNotificacao.title, {
        body: config.proximaNotificacao.body,
        icon: "./icon.svg",
        badge: "./icon.svg",
        vibrate: [200, 100, 200],
        tag: "epi-alerta",
        requireInteraction: true,
        renotify: true
      });
    }
  } catch (e) {
    // silencioso — ambiente pode não suportar
  }
}

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clientList) => {
      if (clientList.length > 0) return clientList[0].focus();
      return self.clients.openWindow("./index.html");
    })
  );
});
